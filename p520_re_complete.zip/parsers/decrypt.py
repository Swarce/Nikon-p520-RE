# Nikon P520 firmware decrypt: ks[i] = K0[i & 0xffff] ^ C[(i>>16) & 0xff]
# K0 = ciphertext of an all-constant plaintext 64K chunk (0x150000), C = per-64K-chunk constant (period 256)
import numpy as np, collections
d=np.fromfile('/mnt/user-data/uploads/firmware.bin',dtype=np.uint8)
n=len(d); K0=d[0x150000:0x160000].copy()
nch=(n+0xffff)//0x10000
pad=np.zeros(nch*0x10000,np.uint8); pad[:n]=d
X=pad.reshape(nch,0x10000)^K0
votes=collections.defaultdict(collections.Counter)
for i,r in enumerate(X[:-1]):
    h=np.bincount(r,minlength=256); votes[i&255][h.argmax()]+=1+h.max()/65536
C=np.array([votes[r].most_common(1)[0][0] for r in range(256)],np.uint8)
P=(X^C[np.arange(nch)&255][:,None]).reshape(-1)[:n]
P[:0x20]=d[:0x20]
P.tofile('dec.bin'); np.save('C.npy',C); K0.tofile('K0.bin')
